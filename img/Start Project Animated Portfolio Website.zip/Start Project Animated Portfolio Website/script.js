var typed = new Typed(".multiple-text", {

})